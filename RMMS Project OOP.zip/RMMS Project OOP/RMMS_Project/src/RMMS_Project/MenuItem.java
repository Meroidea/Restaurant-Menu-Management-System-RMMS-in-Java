package RMMS_Project;


public abstract class MenuItem {
    private int itemNumber;
    private String itemName;
    private String description;
    private double itemPrice;
    private String category;

    public MenuItem(int itemNumber, String itemName, String description, double itemPrice, String category) {
        this.itemNumber = itemNumber;
        this.itemName = itemName;
        this.description = description;
        this.itemPrice = itemPrice;
        this.category = category;
    }

    public int getItemNumber() {
        return itemNumber;
    }

    public String getItemName() {
        return itemName;
    }
    public String getDescription () {
    	return description;
    }

    public double getItemPrice() {
        return itemPrice;
    }

    public String getCategory() {
        return category;
    }

    public abstract double calculatePrice();

    @Override
    public String toString() {
        return String.format("Item Number: %d\nItem Name: %s\nDescription: %s\nPrice: %.2f\nCategory: %s",
                itemNumber, itemName, description, itemPrice, category);
    }

    public static class StandardMenuItem extends MenuItem {
        public StandardMenuItem(int itemNumber, String itemName, String description, double itemPrice, String category) {
            super(itemNumber, itemName, description, itemPrice, category);
        }

        @Override
        public double calculatePrice() {
            return Math.round(getItemPrice() * 1000.0) / 1000.0;
        }
    }

    public static class PremiumMenuItem extends MenuItem {
        private double surchargePercentage;
        

        public PremiumMenuItem(int itemNumber, String itemName, String description, double itemPrice, String category, double surchargePercentage) {
            super(itemNumber, itemName, description, itemPrice, category);
            this.surchargePercentage = surchargePercentage;
            
        }

        @Override
        public double calculatePrice() {
            return Math.round((getItemPrice() + (getItemPrice() * surchargePercentage / 100)) * 1000.0) / 1000.0;
        }
    }

    public static class DiscountMenuItem extends MenuItem {
        public DiscountMenuItem(int itemNumber, String itemName, String description, double itemPrice, String category) {
            super(itemNumber, itemName, description, itemPrice, category);
        }

        @Override
        public double calculatePrice() {
            return Math.round((getItemPrice() * 0.95) * 1000.0) / 1000.0;
        }
    }

    public static class DrinkMenuItem extends MenuItem {
        public DrinkMenuItem(int itemNumber, String itemName, String description, double itemPrice, String category) {
            super(itemNumber, itemName, description, itemPrice, category);
        }

        @Override public double calculatePrice() {
            return Math.round(getItemPrice() * 1000.0) / 1000.0;
        }  
    }	
}