package RMMS_Project;

import java.util.ArrayList;

public class Menu {
    private int id;
    private String name;
    private String purpose;
    private String venue;
    private String sessionTime;
    private ArrayList<MenuItem> items;

    public Menu() {
        this.id = 0;
        this.name = "unknown";
        this.purpose = "unknown";
        this.venue = "unknown";
        this.sessionTime = "unknown";
        this.items = new ArrayList<>();
    }

    public Menu(int id, String name, String purpose, String venue, String sessionTime) {
        this.id = id;
        this.name = name;
        this.purpose = purpose;
        this.venue = venue;
        this.sessionTime = sessionTime;
        this.items = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public String getSessionTime() {
        return sessionTime;
    }

    public void setSessionTime(String sessionTime) {
        this.sessionTime = sessionTime;
    }

    public void addMenuItem(MenuItem item) {
        items.add(item);
    }

    public void removeMenuItem(int itemId) {
        items.removeIf(item -> item.getItemNumber() == itemId);
    }

    public MenuItem getMenuItem(int itemId) {
        for (MenuItem item : items) {
            if (item.getItemNumber() == itemId) {
                return item;
            }
        }
        return null;
    }

    public ArrayList<MenuItem> getItems() {
        return items;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Menu ID: ").append(id).append("\n");
        sb.append("Name: ").append(name).append("\n");
        sb.append("Purpose: ").append(purpose).append("\n");
        sb.append("Venue: ").append(venue).append("\n");
        sb.append("Session Time: ").append(sessionTime).append("\n");
        sb.append("Items:\n");
        for (MenuItem item : items) {
            sb.append(item.toString()).append("\n");
        }
        return sb.toString();
    }
}