package RMMS_Project;

import java.util.ArrayList;
import java.util.Scanner;

public class RestaurantDriver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Welcome message
        System.out.println("Developed by: Sujan, Anthony, Shushil, Santosh\nWelcome To Kent Restaurant!");

        // Create menus
        Menu dineInMenu = new Menu(1, "Dine-In Menu", "Lunch", "Restaurant", "12:00 PM - 3:00 PM");
        Menu takeAwayMenu = new Menu(2, "Take-Away Menu", "Dinner", "Restaurant", "6:00 PM - 9:00 PM");

        // Create menu items for different categories
        ArrayList<MenuItem> breakfastItems = new ArrayList<>();
        breakfastItems.add(new MenuItem.StandardMenuItem(1, "Pancake", "Delicious pancake", 3.75, "breakfast"));
        breakfastItems.add(new MenuItem.StandardMenuItem(2, "Avocado Toast", "Avocado on toast", 6.25, "breakfast"));
        breakfastItems.add(new MenuItem.StandardMenuItem(3, "Scrambled eggs", "Fluffy Scrambles Eggs", 5.50, "breakfast"));
        breakfastItems.add(new MenuItem.StandardMenuItem(4, "Porridge", "Warm porridge", 4.99, "breakfast"));
        breakfastItems.add(new MenuItem.StandardMenuItem(5, "Coffee", "Freshly brewed coffee", 2.99, "breakfast"));

        ArrayList<MenuItem> lunchItems = new ArrayList<>();
        lunchItems.add(new MenuItem.StandardMenuItem(6, "Chicken schnitzel", "Delicious chicken schnitzel", 13.99, "lunch"));
        lunchItems.add(new MenuItem.StandardMenuItem(7, "Lamb Chop", "Juicy lamb chop", 17.50, "lunch"));
        lunchItems.add(new MenuItem.StandardMenuItem(8, "Grilled Baramundi", "Grilled baramundi fillet", 15.75, "lunch"));
        lunchItems.add(new MenuItem.StandardMenuItem(9, "Chicken & Cheese Burger", "Burger with chicken and cheese", 10.25, "lunch"));
        lunchItems.add(new MenuItem.StandardMenuItem(10, "Garden Salad", "Fresh garden salad", 11.49, "lunch"));

        ArrayList<MenuItem> dinnerItems = new ArrayList<>();
        dinnerItems.add(new MenuItem.StandardMenuItem(11, "Lasagna", "Cheesy lasagna", 13.50, "dinner"));
        dinnerItems.add(new MenuItem.StandardMenuItem(12, "Chicken Penne Pesto", "Penne pasta with pesto", 15.75, "dinner"));
        dinnerItems.add(new MenuItem.StandardMenuItem(13, "Salmon with roasted vegetables", "Salmon with veggies", 17.99, "dinner"));
        dinnerItems.add(new MenuItem.StandardMenuItem(14, "Chicken Curry with Rice", "Chicken curry served with rice", 14.25, "dinner"));

        ArrayList<MenuItem> drinksAndDesserts = new ArrayList<>();
        drinksAndDesserts.add(new MenuItem.DrinkMenuItem(15, "Soft Drinks", "Refreshing soft drink", 3.75, "non-alcoholic"));
        drinksAndDesserts.add(new MenuItem.DrinkMenuItem(16, "Fruit Juice", "Healthy fruit juice", 5.50, "non-alcoholic"));
        drinksAndDesserts.add(new MenuItem.DrinkMenuItem(17, "Smoothies", "Delicious smoothies", 6.99, "non-alcoholic"));
        drinksAndDesserts.add(new MenuItem.DrinkMenuItem(18, "Iced Tea", "Cool iced tea", 5.00, "non-alcoholic"));
        drinksAndDesserts.add(new MenuItem.DrinkMenuItem(19, "Beer", "Cold beer", 5.25, "alcoholic"));
        drinksAndDesserts.add(new MenuItem.DrinkMenuItem(20, "Soju", "Popular Korean drink", 12.49, "alcoholic"));
        drinksAndDesserts.add(new MenuItem.DrinkMenuItem(21, "Wine", "Red or white wine", 10.50, "alcoholic"));
        
        
        ArrayList<MenuItem> premiumMenuItems = new ArrayList<>();
        premiumMenuItems.add(new MenuItem.StandardMenuItem(23, "Premium Pasta", "Delicious pasta with premium ingredients", 18.99, "premium"));
        premiumMenuItems.add(new MenuItem.StandardMenuItem(24, "Grilled Lobster", "Grilled lobster with garlic butter", 24.99, "premium"));
        premiumMenuItems.add(new MenuItem.StandardMenuItem(25, "Wagyu Beef Burger", "Juicy Wagyu beef burger with truffle fries", 22.99, "premium"));
        premiumMenuItems.add(new MenuItem.StandardMenuItem(26, "Truffle Risotto", "Creamy truffle risotto with parmesan", 21.99, "premium"));
        premiumMenuItems.add(new MenuItem.StandardMenuItem(27, "Seafood Platter", "Assorted seafood platter with dipping sauce", 29.99, "premium"));
        premiumMenuItems.add(new MenuItem.DrinkMenuItem(28, "Champagne", "Bottle of premium champagne", 59.99, "premium"));
        premiumMenuItems.add(new MenuItem.DrinkMenuItem(29, "Vintage Wine", "Bottle of vintage wine", 79.99, "premium"));
        premiumMenuItems.add(new MenuItem.DrinkMenuItem(30, "Craft Cocktail", "Handcrafted cocktail made with premium spirits", 14.99, "premium"));
        premiumMenuItems.add(new MenuItem.DrinkMenuItem(31, "Specialty Coffee", "Specialty coffee made with rare beans", 8.99, "premium"));
        premiumMenuItems.add(new MenuItem.DrinkMenuItem(32, "Mocktail", "Non-alcoholic mocktail made with exotic flavors", 9.99, "premium"));
        
        ArrayList<MenuItem> discountMenuItems = new ArrayList<>();
        discountMenuItems.add(new MenuItem.DiscountMenuItem(33, "Grilled Chicken Sandwich", "Juicy grilled chicken sandwich with lettuce and tomato", 8.99, "discounted"));
        discountMenuItems.add(new MenuItem.DiscountMenuItem(34, "Vegetarian Pizza", "Delicious vegetarian pizza with assorted veggies", 10.49, "discounted"));
        discountMenuItems.add(new MenuItem.DiscountMenuItem(35, "BBQ Pulled Pork Burger", "Tender BBQ pulled pork burger with coleslaw", 9.75, "discounted"));
        discountMenuItems.add(new MenuItem.DiscountMenuItem(36, "Shrimp Tacos", "Tasty shrimp tacos with salsa and avocado", 11.99, "discounted"));
        discountMenuItems.add(new MenuItem.DiscountMenuItem(37, "Mushroom Risotto", "Creamy mushroom risotto with parmesan cheese", 12.99, "discounted"));
        discountMenuItems.add(new MenuItem.DiscountMenuItem(38, "Tropical Smoothie", "Refreshing tropical smoothie with assorted fruits", 4.99, "discounted"));
        discountMenuItems.add(new MenuItem.DiscountMenuItem(39, "Mango Mojito", "Cool mango mojito with fresh mint and lime", 6.49, "discounted"));



        // Add items to menus
        dineInMenu.getItems().addAll(breakfastItems);
        dineInMenu.getItems().addAll(lunchItems);
        dineInMenu.getItems().addAll(dinnerItems);
        dineInMenu.getItems().addAll(drinksAndDesserts);
        dineInMenu.getItems().addAll(premiumMenuItems);
        dineInMenu.getItems().addAll(discountMenuItems);
        takeAwayMenu.getItems().addAll(breakfastItems);
        takeAwayMenu.getItems().addAll(lunchItems);
        takeAwayMenu.getItems().addAll(dinnerItems);
        takeAwayMenu.getItems().addAll(drinksAndDesserts);
        takeAwayMenu.getItems().addAll(premiumMenuItems);
        takeAwayMenu.getItems().addAll(discountMenuItems);

        // Predefined vouchers
        ArrayList<Voucher> vouchers = new ArrayList<>();
        vouchers.add(new Voucher("DISC5", 5.00));
        vouchers.add(new Voucher("DISC10", 0.10));
        vouchers.add(new Voucher("DISC25", 0.25));
        vouchers.add(new Voucher("DISC50", 0.50));
        vouchers.add(new Voucher("FREE100", 1.00));
        
      

        // Get customer details
        System.out.print("Please enter your name: ");
        String customerName = scanner.nextLine();
        
        // Check if customerName is empty
        if (customerName.isEmpty()) {
            System.out.println("Invalid! No name provided.");
        } else {
            System.out.println("Hello, " + customerName + "! Welcome.");
            
        // Validate customer status
        String customerStatus;
        while (true) {
            System.out.println("\nWhat is your customer status with us (Active - 10% Discount / VIP - 15% Discount / New - No Discount)? ");
            customerStatus = scanner.nextLine();
            if (customerStatus.equalsIgnoreCase("Active") || customerStatus.equalsIgnoreCase("VIP") || customerStatus.equalsIgnoreCase("New")) {
                break;
            } else {
                System.out.println("Invalid input. Please enter a valid customer status (Active/VIP/New).");
            }
        }

        Customer customer = new Customer(customerName, customerStatus);

        // Validate menu type
        int menuChoice;
        while (true) {
            System.out.println("Please choose the menu type? ");
            System.out.println("1. Dine-in");
            System.out.println("2. Take Away");
            menuChoice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            if (menuChoice == 1 || menuChoice == 2) {
                break;
            } else {
                System.out.println("Wrong input. Please select either 1 for Dine-in or 2 for Take Away.");
            }
        }

        boolean isDineIn = (menuChoice == 1);
        Order order = new Order(customer, isDineIn);
        Menu selectedMenu = isDineIn ? dineInMenu : takeAwayMenu;

        // Ask for category
        System.out.println("Please choose our menu category:");
        System.out.println("1. Breakfast");
        System.out.println("2. Lunch");
        System.out.println("3. Dinner");
        System.out.println("4. Premium");
        System.out.println("5. Discounted");
        int categoryChoice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String category = "";
        switch (categoryChoice) {
            case 1:
                category = "breakfast";
                break;
            case 2:
                category = "lunch";
                break;
            case 3:
                category = "dinner";
                break;
            case 4:
            	category = "premium";
            	break;
            case 5:
            	category = "discounted";
            	break;
            default:
                System.out.println("Invalid choice. Defaulting to 'lunch'.");
                category = "lunch";
        }

        // Display items in the selected menu and category
        System.out.println(category.substring(0, 1).toUpperCase() + category.substring(1) + " Menu Items:");
        for (MenuItem item : selectedMenu.getItems()) {
            if (item.getCategory().equals(category)) {
                System.out.println(item.getItemNumber() + ". " + item.getItemName() + " - " + item.getDescription()+ " ($" + item.calculatePrice() + ")");
            }
        }

        // Take orders
        while (true) {
            System.out.println("Order another item or type done if youre done.");
            String itemNumberInput = scanner.nextLine();
            if (itemNumberInput.equalsIgnoreCase("done")) {
                break;
            }
            int itemNumber = Integer.parseInt(itemNumberInput);
            MenuItem orderedItem = selectedMenu.getMenuItem(itemNumber);
            if (orderedItem != null && orderedItem.getCategory().equals(category)) {
                System.out.println("Quantity of " + orderedItem.getItemName() + "? ");
                int quantity = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                order.addMenuItem(orderedItem, quantity);
            } else {
                System.out.println("Invalid item number or category.");
            }
        }

        // Ask for drinks or desserts
        while (true) {
            System.out.println("Would you like to add any drinks (yes/no)? ");
            String drinksResponse = scanner.nextLine();
            if (!drinksResponse.equalsIgnoreCase("yes")) {
                break;
            }

            // Ask for drink type
            System.out.print("Would you like to order alcoholic or non-alcoholic drinks?");
            String drinkType = scanner.nextLine();
            if (drinkType.equalsIgnoreCase("alcoholic")) {
                System.out.println("You need to be above 18 years of age to order alcoholic drinks. Please enter your age?");
                int age = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                if (age < 18) {
                    System.out.println("Sorry! You are minor. We cannot serve you alcohol.");
                    continue;
                } else {
                    // Display alcoholic drinks menu
                    System.out.println("Please select from our Alcoholic drinks menu:");
                    for (MenuItem item : drinksAndDesserts) {
                        if (item.getCategory().equals("alcoholic")) {
                            System.out.println(item.getItemNumber() + ". " + item.getItemName() + " - " + item.getDescription() + " ($" + item.calculatePrice() + ")");
                        }
                    }
                }
            } else if (drinkType.equalsIgnoreCase("non-alcoholic")) {
                System.out.println("Please select from our Non-Alcoholic drinks menu:");
                for (MenuItem item : drinksAndDesserts) {
                    if (item.getCategory().equals("non-alcoholic")) {
                        System.out.println(item.getItemNumber() + ". " + item.getItemName() + " - " + item.getDescription() + " ($" + item.calculatePrice() + ")");
                    }
                }
            } else {
                System.out.println("Invalid choice. Please choose 'alcoholic' or 'non-alcoholic'.");
                continue;
            }

            // Take orders for drinks and desserts
            while (true) {
                System.out.println("Order another item or type done if youre done.");
                String itemNumberInput = scanner.nextLine();
                if (itemNumberInput.equalsIgnoreCase("done")) {
                    break;
                }
                int itemNumber = Integer.parseInt(itemNumberInput);
                MenuItem orderedItem = selectedMenu.getMenuItem(itemNumber);
                if (orderedItem != null && orderedItem.getCategory().equals(drinkType.toLowerCase())) {
                    System.out.println("Quantity of " + orderedItem.getItemName() + "? ");
                    int quantity = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    order.addMenuItem(orderedItem, quantity);
                } else {
                    System.out.println("Invalid item number or category.");
                }
            }
        }

        // Ask for voucher code
        double voucherDiscount = 0.0;
        System.out.println("Do you have any discount vouchers(yes/no)? ");
        String voucherResponse = scanner.nextLine();
        if (voucherResponse.equalsIgnoreCase("yes")) {
            System.out.println("Please enter the Voucher code: ");
            String voucherCode = scanner.nextLine();
            for (Voucher voucher : vouchers) {
                if (voucher.getCode().equalsIgnoreCase(voucherCode)) {
                    if (voucher.getDiscount() <= 1.0) {
                        System.out.println("Great! Items a " + (voucher.getDiscount() * 100) + "% discount voucher.");
                        order.applyPercentageVoucherDiscount(voucher.getDiscount());
                    } else {
                        System.out.println("Great! Items a $" + voucher.getDiscount() + " discount voucher.");
                        order.applyVoucherDiscount(voucher.getDiscount());
                    }
                    voucherDiscount = voucher.getDiscount();
                    break;
                }
            }
            if (voucherDiscount == 0.0) {
                System.out.println("Invalid voucher code.");
            }
        } else if (!voucherResponse.equalsIgnoreCase("no")) {
            System.out.println("Error: Invalid response. Please enter 'yes' or 'no'.");
        }
            
        // Ask for payment method
        System.out.println("Please select your payment method;");
        System.out.println("1. Cash");
        System.out.println("2. Debit/Credit Card (There is surcharge of 1.8%)");
        
        int paymentMethod = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        boolean isDebitcredit = (paymentMethod == 2);
     
        // Calculate total and generate invoice
        order.calculateTotal();
        if (isDebitcredit) {
            order.applySurcharge(1.8);
           
        }
        String invoice = order.generateInvoice("Kent Restaurant", "10 Barrack Street, Sydney");
        System.out.println(invoice);

        scanner.close();
        }
   }
}