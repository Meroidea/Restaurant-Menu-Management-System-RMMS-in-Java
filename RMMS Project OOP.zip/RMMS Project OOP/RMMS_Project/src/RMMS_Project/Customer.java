package RMMS_Project;

public class Customer {
    private String name;
    private String status;
    private double discount;
    private int tableNumber;

    public Customer(String name, String status) {
        this.name = name;
        this.status = status;
        setDiscount();
    }

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public double getDiscount() {
        return discount;
    }
    public int getTableNumber () {
    	return tableNumber;
    }

    private void setDiscount() {
        if (status.equalsIgnoreCase("VIP")) {
            this.discount = 0.15;
        } else if (status.equalsIgnoreCase("Active")) {
            this.discount = 0.10;
        } else {
        	this.discount = 0.0;
        }
    }

    @Override
    public String toString() {
        return "Customer Name: " + name + "\nStatus: " + status  + "\nDiscount: " + discount;
    }
}
