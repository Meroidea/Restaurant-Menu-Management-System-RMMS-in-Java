package RMMS_Project;

import java.util.ArrayList;

public class Order {
    private Customer customer;
    private ArrayList<MenuItem> orderedItems;
    private ArrayList<Integer> quantities;
    private double totalAmount;
    private double voucherDiscount;
    private double surcharge;
    private boolean isDineIn;
    private int tableNumber;

    public Order(Customer customer, boolean isDineIn) {
        this.customer = customer;
        this.orderedItems = new ArrayList<>();
        this.quantities = new ArrayList<>();
        this.totalAmount = 0.0;
        this.voucherDiscount = 0.0;
        this.surcharge = 0.0;
        this.isDineIn = isDineIn;
        if (isDineIn) {
            this.tableNumber = (int) (Math.random() * 25) + 1; // Random table number between 1 and 25
        }
    }

    public void addMenuItem(MenuItem item, int quantity) {
        orderedItems.add(item);
        quantities.add(quantity);
    }

    public void calculateTotal() {
        totalAmount = 0.0;
        for (int i = 0; i < orderedItems.size(); i++) {
            totalAmount += orderedItems.get(i).calculatePrice() * quantities.get(i);
        }
    }

    public void applyVoucherDiscount(double discount) {
        this.voucherDiscount = discount;
        totalAmount -= discount;
    }

    public void applyPercentageVoucherDiscount(double discountPercentage) {
        this.voucherDiscount = totalAmount * discountPercentage;
        totalAmount -= this.voucherDiscount;
    }

    public void applySurcharge(double surchargePercentage) {
        // Check if it's a dine-in order
        if (isDineIn) {
            // Add 2.5% service charge
            this.surcharge = totalAmount * (surchargePercentage + 2.5) / 100;
        } else {
            // For take-away orders, only apply the provided surcharge percentage
            this.surcharge = totalAmount * surchargePercentage / 100;
        }
       
        totalAmount += this.surcharge;
    }

    public String generateInvoice(String restaurantName, String restaurantAddress) {
        StringBuilder sb = new StringBuilder();
        sb.append("Kent Restaurant\n")
          .append("10 Barrack Street, Sydney\n")
          .append("Local time: ").append(java.time.LocalTime.now().withNano(0)).append("\n\n")
          .append("Customer: ").append(customer.getName()).append(" (").append(customer.getStatus()).append(" customer)\n");
        if (isDineIn) {
            sb.append("Table no.: ").append(tableNumber).append("\n\n");
        }
        sb.append("Food ordered:\n");
        for (int i = 0; i < orderedItems.size(); i++) {
            sb.append(orderedItems.get(i).getItemName()).append(" - $")
              .append(String.format("%.3f", orderedItems.get(i).calculatePrice())).append(" x ")
              .append(quantities.get(i)).append("\n");
        }
        if (surcharge > 0) {
            sb.append("Debit/Card card surcharge: $").append(String.format("%.2f", surcharge)).append("\n");
        }
        sb.append("Total: $").append(String.format("%.2f", totalAmount)).append("\n");
        if (voucherDiscount > 0) {
            sb.append("Voucher Discount: $").append(String.format("%.2f", voucherDiscount)).append("\n");
        }
        double customerDiscount = customer.getDiscount() * (totalAmount - surcharge);
        if (customer.getDiscount() > 0) {
            sb.append("Customer discount: $").append(String.format("%.2f", customer.getDiscount() * (totalAmount - surcharge))).append("\n");
        
        }
        double totalAmountDue = totalAmount - voucherDiscount - customerDiscount ;
        sb.append("Total amount due: $").append(String.format("%.2f", totalAmountDue)).append("\n")
          .append("Thank you! See you again.");
        return sb.toString();
    }

    public double getTotalAmount() {
        return totalAmount;
    }
}